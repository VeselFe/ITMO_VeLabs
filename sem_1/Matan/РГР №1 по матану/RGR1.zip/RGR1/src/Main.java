@FunctionalInterface
interface Functions { double apply(double x); }

@FunctionalInterface
interface AnalyticDerivatives { 
    double apply(double x); 
}

public class Main{
   public static void main(String[] args) {
      Derivative myDerivative = new Derivative();
      Function myFunction = new Function();


      //функции для дифферинцирования
      Functions[] functions = {
            //1  e^-x * sin(x)
            x -> Math.pow(Math.E, -x) * Math.sin(x),
            //2 e^x/(x^2 +1)
            x -> Math.pow(Math.E, x) /(x*x +1),
            //3 1/(1+e^-x)
            x -> 1 /(1 + Math.pow(Math.E, -x)),
            //4 tanH(x)
            x -> (Math.pow(Math.E, x)-Math.pow(Math.E, -x)) / (Math.pow(Math.E, x)+Math.pow(Math.E, -x)),
            //5 sin(x)/x
            x -> Math.sin(x)/x,
            // f(x) = e^{sin(x²)}
            x -> Math.exp(Math.sin(x * x)),    
            // f(x) = √(1 + x * ln(x))
            x -> Math.sqrt(1 + x * Math.log(x)),
            
            // f(x) = ln(cos x)
            x -> Math.log(Math.cos(x)),
            
            // f(x) = sin(cos(sin x))
            x -> Math.sin(Math.cos(Math.sin(x))),
            
            // f(x) = sin(ln x)
            x -> Math.sin(Math.log(x)), 

            //x -> Math.sin(1/(x+0.00000001))
           // x -> Math.abs(x-1.5)
            //x -> 1/(x-1.5)
            x->Math.cbrt(x-1.5)
    };
    //Аналитическое решение производной для сравнения
    AnalyticDerivatives[] analFunctions = {
            //1  e^-x * sin(x)
            x -> -1 * Math.pow(Math.E, -x) * Math.sin(x) + Math.pow(Math.E, -x) * Math.cos(x),
            //2 e^x/(x^2 +1)
            x -> (Math.pow(Math.E, x) * (x*x +1) - 2*x * Math.pow(Math.E, x)) /((x*x +1)*(x*x + 1)),
            //3 1/(1+e^-x)
            x -> (Math.pow(Math.E, -x)) /((1 + Math.pow(Math.E, -x))*(1 + Math.pow(Math.E, -x))),
            //4 tanH(x)
            x -> 0,
            //5 sin(x)/x
            x -> (Math.cos(x)*x - Math.sin(x))/(x*x),
            // f(x) = e^{sin(x²)}
            x -> Math.exp(Math.sin(x * x)) * Math.cos(x*x) * 2*x,    
            // f(x) = √(1 + x * ln(x))
            x -> 1/(Math.sqrt(1 + x * Math.log(x))) * (Math.log(x) + 1) * 0.5,
            
            // f(x) = ln(cos x)
            x -> (-1*Math.sin(x)) / Math.cos(x),
            
            // f(x) = sin(cos(sin x))
            x -> Math.cos(Math.cos(Math.sin(x))) * (-1)*Math.sin(Math.sin(x)) * Math.cos(x),
            
            // f(x) = sin(ln x)
            x -> Math.cos(Math.log(x)) * (1/x), 

            x -> 1/(Math.cbrt(x)*Math.cbrt(x)) * (0.333333333333333333)
    };
   // Подпись для функций
    String[] names = {
            "e^-x * sin(x)", "e^x/(x^2 +1)","1/(1+e^-x)", "tanH(x)","sin(x)/x", "e^{sin(x²)}", "√(1+x*ln(x))", "ln(cos x)", 
            "sin(cos(sin x))", "sin(ln x)", "(x)^1/3"
        };
      //точка дифферинцирования, максимальное значение дельта, минимальное значение дельта
      double x0 = 1.5, tolerance = 1e-12, epsilon = 1e-16;

      //вывод результата
       for (int i = 0; i < functions.length; i++)
       {
         double myData = myDerivative.getDerivative(functions[i], x0, tolerance, epsilon).value, myAnal = analFunctions[i].apply(x0);

          System.out.println(names[i]+" | " + myAnal + " | " + myDerivative.getDerivative(functions[i], x0, tolerance, epsilon) + " | " + myDerivative.getDerivativeDepth() + " | " + "error");
       }
   }
};