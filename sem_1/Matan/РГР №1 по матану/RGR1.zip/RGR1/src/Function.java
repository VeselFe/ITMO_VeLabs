public  class Function {
   public Function(){

   }

   public double getValue(double x) {
      return Math.cbrt(x);
      //return Math.abs(x);
      //return Math.pow(Math.E, Math.sin(x*x));
   }
}
