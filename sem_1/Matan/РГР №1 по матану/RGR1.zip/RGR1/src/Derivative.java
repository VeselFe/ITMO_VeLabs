public class Derivative {
   public Derivative() {

   }
   private int cnt = 0, infCnt = 0;
   private double h = 1.0;

   public Result getDerivative(Functions curFunction,double x0, double tolerance, double epsilon) {
      //epsilon = 1e-15;
       double prevDerivative = 0.0, curDerivative = 0.0, derivativeDiff = 10000, curDerivativeDiff = 0,  bestSolution = -255, curSolution = -255, hmax = 0;
      cnt = 1;
      h = 10.0;
      boolean isInf = false, calculated = false, tolerancePass = false;

      //проверка на нан опциональна

      /*if(""+curFunction.apply(x0) == "NaN") {
            Result result = new Result(-255, "Функция не определена в этой точке - разрыв", false);
            return result;
      }*/
      double curDerivative1, curDerivative2, delta;   
      while(true) {
         //расчет производной с шагом h  и h/2
         curDerivative1 = ((curFunction.apply(x0+h)) - curFunction.apply(x0-h))/(2*h);
         curDerivative2 = ((curFunction.apply(x0+(h/2))) - curFunction.apply(x0-(h/2)))/(h);

         //расчет дельта по Рунге
         delta = Math.abs(curDerivative1 - curDerivative2)/(Math.pow(2, cnt) - 1);

         if(Math.abs(curDerivative1 - curDerivative2) > curDerivativeDiff) {
               if(Math.abs(curDerivative1 - curDerivative2) > 10000)
                  isInf = true;
               //System.out.println("111");
            }
         curDerivativeDiff = Math.abs(curDerivative1 - curDerivative2);

         //Проверка правила рунге
         if(delta < tolerance && delta > epsilon && delta != 0.0) {
            Result result = new Result(curDerivative, "Производная рассчитана", true);
            bestSolution = curDerivative1;
            tolerancePass = true;
            calculated = true;
            hmax = h;
         }//если не прошло, но значение норм - запоминаем на случай, если мы никогда не дойдем до нужной точности, чтобы был хоть какой-нибудь результат
         else if(delta > epsilon && delta != 0.0) {
            calculated = true;
            curSolution = curDerivative1;
            hmax = h;
         }
         //останов по кол-ву витков цикла <=> 2^-p настолько мал, что уже равен 0
         if(cnt == 100) {
            //Если производная где-то росла и при этом стала больше 10_000 значит, вероятно, это вертикальная прямая
            if(isInf == true) {
                  Result result = new Result(-255, "вертикальная прямая", false);
                  return result;
               }
               //если прошли проверку delta < epsilon - правило рунге
               else if (tolerancePass == true) {
                  Result result = new Result(bestSolution, "Производная рассчитана", true);
                  return result;
               }
               //если не прошли правило Рунге и имеем нормальное значение
               else if(calculated == true) {
                  Result result = new Result(curSolution, "tolerance не был достигнут", true);
                  return result;
               }
               //если все плохо
               else {
                  Result result = new Result(curSolution, "Ошибка - функция недифферинцируема", false);
                  return result;
               }
         }
         cnt += 1;
          h /= 2.0;
         prevDerivative = curDerivative;
         
      }
   }

   public int getDerivativeDepth() {
      return cnt;
   }

   public double getHStep() {
      return h;
   }
}
