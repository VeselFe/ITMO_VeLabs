public class Result {
   public double value;
   public String comment;
   public boolean correct;
   public Result (double value, String comment, boolean correct) {
      this.value = value;
      this.comment = comment;
      this.correct = correct;
   }

   public String toString() {
      if(correct != false)
         return ( value +" " + comment);
      else
         return comment;
   }
}
