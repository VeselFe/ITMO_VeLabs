package locations;
import myobjects.MyObject;
import renders.ChangesRender;

public class Location extends MyObject
{
    private String Description = "Here will be description of location";
    protected final ChangesRender changeLocRender;
    Location( String NewName, ChangesRender renderer )
    {
        this.changeLocRender = renderer;
        super(NewName);
    }
    public String getDesciption()
    {
        return Description;
    }
    public void setDescription( String NewDescription )
    {
        Description = NewDescription;
    }
}
