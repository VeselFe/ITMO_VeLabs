package characters;
import interfaces.Greetable;

final public class ChineseDoll extends MyCharacter implements Greetable
{

    static int number = 1;
    public ChineseDoll( String Name, String NewSize, String NewLocation )
    {
      super( Name +  " #" + number, NewSize, NewLocation );
      number += 1;
    }
    public ChineseDoll( String Name )
    {
      super( Name +  " #" + number );
      number += 1;
    }
    public ChineseDoll()
    {
      super();
      number += 1;
    }    

    @Override 
    public String greet( MyCharacter person )
    {
      return "Приветствует " + person.getName();
    }
}