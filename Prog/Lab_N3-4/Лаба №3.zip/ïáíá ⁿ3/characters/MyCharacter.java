package characters;

import interfaces.Speakable;
import myobjects.*;
import renders.SpeechRenderer;

abstract public class MyCharacter extends MyObject implements Speakable
{
    private String Size = "Niether BIG nor SMALL";
    private String Location = "nowhere";
    private String Emotion = "NoEmotion";

    public MyCharacter( String Name, String NewSize, String NewLocation )
    {
      super(Name);
      Size = NewSize;
      Location = NewLocation;
      // System.out.println("New character '" + Name + "' was created!");
    }
    public MyCharacter( String Name, String NewSize )
    {
      super(Name);
      Size = NewSize;
      // System.out.println("New character '" + Name + "' was created!");
    }    
    public MyCharacter( String Name )
    {
      super(Name);
      // System.out.println("New character '" + Name + "' was created!");
    }  
    public MyCharacter()
    {
      super("");
    }  

    public void setLocation( String NewLocation, SpeechRenderer renderer ) 
    {
      Location = NewLocation;
      renderer.printMessage(super.getName(), "'s location switched - new location: " + Location);
    }
    
    @Override
    public String speak( String phrase )
    {
      return phrase;
    }
}