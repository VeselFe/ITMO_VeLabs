package characters;
import interfaces.Speakable;

final public class MainCharacter extends MyCharacter implements Speakable
{
    private boolean confusion = false;
    public MainCharacter( String Name, String NewSize, String NewLocation )
    {
      super(Name,NewSize,NewLocation);
    }

    public void confused()
    {
      this.confusion = true;
    }
    public void calmedDown()
    {
      this.confusion = false;
    }
    @Override
    public String speak(String phrase) {
        if (confusion) {
            return " (в замешательстве): " + phrase;
        }
        return ": " + phrase;
    }    
}