javac *.java
for /d %%d in (*) do javac "%%d\*.java"

echo Lab3 was created!
